# ScryHost — Android Studio source project

This is a Kotlin Android app source project based on the ScryHost design. The launcher icon uses the user-provided photo.

## Functional UI and local features in this source
- Home dashboard and navigation to Scripts, Terminal, Packages and More
- System document picker to import files into the app-private scripts directory
- ZIP import with archive entries flattened to safe filenames
- List imported files, create scripts, edit/save script content, delete imported copies, run/stop process attempts, and view per-script output
- Local terminal page with command input, output, built-in `help`, `pwd`, `ls`, `cat <filename>`, `clear`, and Android app-context shell commands
- Runtime availability check and `pip install` attempt when a Python executable is present
- Settings for keep-screen-on, start/stop foreground service and Android app settings
- Keep Alive options, ping check, and combined logs view

## Important runtime limitations
This is **not verified as a complete hosting runtime or crash-free APK**. Android's app sandbox does not automatically provide Python, Node.js, or pip executables. `.py` and `.js` execution and pip installation require compatible runtimes bundled or installed in the app environment; this source does not bundle them. Android shell commands are restricted by the app sandbox and are not a full Linux terminal. Telegram bot hosting, persistent per-script supervision, restart-on-crash, and long-duration background execution have not been validated. Android battery and foreground-service policies may limit background work.

## Build
1. Open `PocketPythonHost` in Android Studio with Android SDK Platform 35 and JDK 17.
2. Sync Gradle.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

No APK is included because this environment has no verified Android Gradle build setup. Compile and test on a device before installing or relying on it.
