package com.example.pocketpythonhost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 9, 22)
    private val panel = Color.rgb(12, 20, 42)
    private val panel2 = Color.rgb(16, 28, 54)
    private val purple = Color.rgb(160, 86, 255)
    private val cyan = Color.rgb(45, 220, 235)
    private val green = Color.rgb(50, 232, 163)
    private val muted = Color.rgb(156, 174, 204)
    private var serviceRunning = false
    private val PICK_FILE = 501
    private val scriptsDir by lazy { java.io.File(filesDir, "scripts").apply { mkdirs() } }
    private val terminalHistory = StringBuilder("ScryHost local console\nType help for commands.\n")
    private lateinit var status: TextView
    private val runningProcesses = ConcurrentHashMap<String, Process>()
    private val runLogs = ConcurrentHashMap<String, StringBuilder>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()
        window.decorView.keepScreenOn = getSharedPreferences("scryhost", MODE_PRIVATE).getBoolean("keep_screen_on", false)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "𝐒ᴄʀʏHost"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD_ITALIC)
        }
        val owner = TextView(this).apply {
            text = "♛  OWNER"
            textSize = 11f
            setTextColor(Color.rgb(255, 194, 94))
            background = pill(Color.rgb(55, 38, 58), Color.rgb(111, 76, 119))
            setPadding(dp(11), dp(7), dp(11), dp(7))
        }
        brandRow.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        brandRow.addView(owner)
        page.addView(brandRow)
        page.addView(label("PYTHON  •  NODE.JS  •  TELEGRAM", 11f, cyan).apply { setPadding(0, dp(3), 0, dp(16)) })

        val hero = card(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(35, 25, 76), Color.rgb(9, 44, 70)))
        hero.setPadding(dp(17), dp(17), dp(17), dp(17))
        hero.addView(label("✦  YOUR LITTLE HOSTING SPACE", 11f, muted))
        status = label(if (serviceRunning) "●  SERVICE RUNNING" else "●  READY TO START", 22f, if (serviceRunning) green else Color.WHITE)
        status.setPadding(0, dp(10), 0, dp(4))
        hero.addView(status)
        hero.addView(label("Keep your scripts organised, one place at a time.", 12f, muted))
        page.addView(hero, marginParams(bottom = 14))

        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metrics.addView(metric("20", "SCRIPT SLOTS", purple), LinearLayout.LayoutParams(0, dp(80), 1f))
        metrics.addView(metric("Python", "RUNTIME", cyan), LinearLayout.LayoutParams(0, dp(80), 1f).apply { leftMargin = dp(8) })
        metrics.addView(metric("Node.js", "RUNTIME", Color.rgb(255, 118, 192)), LinearLayout.LayoutParams(0, dp(80), 1f).apply { leftMargin = dp(8) })
        page.addView(metrics, marginParams(bottom = 14))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = actionButton("▶  Start Service", green, Color.rgb(4, 39, 39)) {
            val intent = Intent(this@MainActivity, HostService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            serviceRunning = true
            status.text = "●  SERVICE REQUESTED"
            status.setTextColor(green)
            Toast.makeText(this@MainActivity, "Background service start requested", Toast.LENGTH_SHORT).show()
        }
        val stop = actionButton("■  Stop Service", Color.rgb(255, 91, 133), Color.rgb(48, 15, 37)) {
            stopService(Intent(this@MainActivity, HostService::class.java))
            serviceRunning = false
            status.text = "●  SERVICE STOPPED"
            status.setTextColor(Color.rgb(255, 145, 169))
            Toast.makeText(this@MainActivity, "Background service stopped", Toast.LENGTH_SHORT).show()
        }
        actions.addView(start, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(stop, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(9) })
        page.addView(actions, marginParams(bottom = 10))

        val quickActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quickActions.addView(actionButton("↻  Restart All", purple, Color.rgb(31, 20, 58)) {
            runningProcesses.values.toList().forEach { proc -> try { proc.destroy() } catch (_: Exception) {} }
            runningProcesses.clear()
            stopService(Intent(this@MainActivity, HostService::class.java))
            val intent = Intent(this@MainActivity, HostService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            serviceRunning = true
            status.text = "●  SERVICE RESTART REQUESTED"
            status.setTextColor(cyan)
            Toast.makeText(this@MainActivity, "Service restart requested (scripts are not connected yet)", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        quickActions.addView(actionButton("♡  Ping Check", cyan, Color.rgb(8, 34, 50)) {
            runPingCheck()
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(9) })
        page.addView(quickActions, marginParams(bottom = 22))

        page.addView(sectionTitle("YOUR WORKSPACE", "✧"), marginParams(bottom = 10))
        val grid1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid1.addView(tile("▣", "Scripts", "Manage .py & .js files", purple) { showScripts() }, LinearLayout.LayoutParams(0, dp(104), 1f))
        grid1.addView(tile("⌁", "Terminal", "Live logs & commands", cyan) { showTerminal() }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(10) })
        page.addView(grid1, marginParams(bottom = 10))
        val grid2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid2.addView(tile("⬡", "Packages", "pip modules", Color.rgb(255, 183, 90)) { showPackages() }, LinearLayout.LayoutParams(0, dp(104), 1f))
        grid2.addView(tile("⚙", "Settings", "App & service settings", Color.rgb(255, 118, 192)) { showSettings() }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(10) })
        page.addView(grid2, marginParams(bottom = 10))
        val grid3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid3.addView(tile("▤", "Files", "Upload .py / .js / .zip", cyan) { launchFilePicker() }, LinearLayout.LayoutParams(0, dp(104), 1f))
        grid3.addView(tile("◷", "Logs", "Output & error history", Color.rgb(255, 118, 192)) { showLogs() }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(10) })
        page.addView(grid3, marginParams(bottom = 10))
        val grid4 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid4.addView(tile("⇧", "Add Script", "Choose or create file", Color.rgb(255, 183, 90)) { createScriptDialog() }, LinearLayout.LayoutParams(0, dp(104), 1f))
        grid4.addView(tile("♥", "Keep Alive", "Background options", green) { showKeepAlive() }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(10) })
        page.addView(grid4, marginParams(bottom = 18))

        page.addView(sectionTitle("RECENT SCRIPTS", "↗"), marginParams(bottom = 10))
        val list = card()
        list.setPadding(dp(12), dp(4), dp(12), dp(4))
        val recentFiles = scriptsDir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }?.take(5) ?: emptyList()
        if (recentFiles.isEmpty()) {
            list.addView(label("No imported scripts yet. Open Files or Scripts to add one.", 12f, muted).apply { setPadding(dp(6), dp(14), dp(6), dp(14)) })
        } else {
            recentFiles.forEachIndexed { index, file ->
                val accent = when (file.extension.lowercase()) { "py" -> green; "js" -> cyan; else -> Color.rgb(255, 183, 90) }
                list.addView(scriptRow(if (file.extension.lowercase() == "js") "JS" else if (file.extension.lowercase() == "py") "Py" else "•", file.name, "${file.extension.uppercase()}  •  Tap to manage", accent).apply { setOnClickListener { showScripts() } })
                if (index < recentFiles.lastIndex) list.addView(separator())
            }
        }
        page.addView(list, marginParams(bottom = 14))
        page.addView(label("𝐒ᴄʀʏ  ×  #ᴠᴇɴᴏᴍ   ♡", 12f, purple).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(10)) })
        page.addView(label("Design preview • Runtime integration still required", 10f, muted).apply { gravity = Gravity.CENTER })

        scroll.addView(page)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = rounded(panel2, 22, Color.rgb(38, 54, 91))
        }
        listOf("⌂\nHome", "▣\nScripts", "⌁\nTerminal", "⬡\nPackages", "•••\nMore").forEachIndexed { index, item ->
            val t = TextView(this).apply {
                text = item
                gravity = Gravity.CENTER
                textSize = 11f
                setTextColor(if (index == 0) cyan else muted)
                setPadding(dp(5), dp(2), dp(5), dp(2))
                setOnClickListener {
                    when (index) {
                        0 -> showHome()
                        1 -> showScripts()
                        2 -> showTerminal()
                        3 -> showPackages()
                        else -> showMore()
                    }
                }
            }
            nav.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(10)) })
        setContentView(root)
    }



    private fun showMore() {
        val (root, page) = screenRoot("More", "All ScryHost tools and app controls")
        page.addView(tile("▤", "Files", "Import from this device", cyan) { launchFilePicker() }, marginParams(bottom = 9))
        page.addView(tile("⇧", "Add Script", "Create and edit a script", Color.rgb(255, 183, 90)) { createScriptDialog() }, marginParams(bottom = 9))
        page.addView(tile("◷", "Logs", "Terminal output and script errors", Color.rgb(255, 118, 192)) { showLogs() }, marginParams(bottom = 9))
        page.addView(tile("⚙", "Settings", "Screen and service settings", Color.rgb(255, 118, 192)) { showSettings() }, marginParams(bottom = 9))
        page.addView(tile("♥", "Keep Alive", "Background service options", green) { showKeepAlive() }, marginParams(bottom = 9))
        page.addView(tile("⬡", "Packages", "Runtime checks and pip installer", Color.rgb(255, 183, 90)) { showPackages() }, marginParams(bottom = 9))
        page.addView(actionButton("‹ Back to Home", purple, panel2) { showHome() })
        setContentView(root)
    }

    private fun launchFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try { startActivityForResult(intent, PICK_FILE) }
        catch (_: Exception) { showInfo("Files", "Device file picker could not be opened.") }
    }

    @Deprecated("Uses Activity result API for compatibility with this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_FILE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val rawName = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: "imported_file.txt"
            val safeName = rawName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
            val dest = java.io.File(scriptsDir, safeName)
            contentResolver.openInputStream(uri).use { stream ->
                requireNotNull(stream) { "Cannot read selected file" }.use { input -> dest.outputStream().use { output -> input.copyTo(output) } }
            }
            if (dest.extension.equals("zip", ignoreCase = true)) {
                var extracted = 0
                java.util.zip.ZipInputStream(dest.inputStream()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val name = entry.name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
                            if (name.isNotBlank() && name != "." && name != "..") {
                                val out = java.io.File(scriptsDir, name).canonicalFile
                                if (out.parentFile == scriptsDir.canonicalFile) { out.outputStream().use { output -> zip.copyTo(output) }; extracted++ }
                            }
                        }
                        zip.closeEntry(); entry = zip.nextEntry
                    }
                }
                Toast.makeText(this, "ZIP imported: $extracted file(s) extracted", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Imported: ${dest.name}", Toast.LENGTH_LONG).show()
            }
            showScripts()
        } catch (e: Exception) {
            showInfo("Import failed", e.message ?: "Could not copy the selected file.")
        }
    }

    private fun showScripts() {
        val root = screenRoot("Scripts", "Imported files appear here. Tap Run to launch a script.")
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("＋ Import file", cyan, Color.rgb(8, 34, 50)) { launchFilePicker() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        actions.addView(actionButton("＋ New script", purple, Color.rgb(31, 20, 58)) { createScriptDialog() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(8) })
        root.second.addView(actions, marginParams(bottom = 12))
        val files = scriptsDir.listFiles()?.filter { it.isFile }?.sortedBy { it.name.lowercase() } ?: emptyList()
        if (files.isEmpty()) root.second.addView(label("No imported scripts yet. Use Import file to select .py or .js files from your phone.", 14f, muted).apply { setPadding(dp(6), dp(18), dp(6), dp(18)) })
        files.forEach { file ->
            val row = card().apply { setPadding(dp(12), dp(12), dp(12), dp(12)) }
            row.addView(label(file.name, 15f, Color.WHITE))
            row.addView(label("${file.length()} bytes  •  ${file.extension.uppercase()}", 11f, muted).apply { setPadding(0, dp(3), 0, dp(9)) })
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.addView(actionButton("▶ Run", green, Color.rgb(4, 39, 39)) { runScript(file) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            buttons.addView(actionButton("■ Stop", Color.rgb(255, 91, 133), Color.rgb(48, 15, 37)) { stopScript(file) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
            buttons.addView(actionButton("Edit", purple, Color.rgb(31, 20, 58)) { editScriptDialog(file) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
            buttons.addView(actionButton("Output", cyan, Color.rgb(8, 34, 50)) { showScriptOutput(file) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
            row.addView(buttons)
            row.addView(actionButton("Delete file", Color.rgb(255, 91, 133), Color.rgb(48, 15, 37)) {
                android.app.AlertDialog.Builder(this).setTitle("Delete ${file.name}?")
                    .setMessage("This removes the imported copy from ScryHost. The original phone file is unchanged.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                        try { stopScript(file); file.delete(); showScripts() }
                        catch (e: Exception) { showInfo("Delete failed", e.message ?: "Could not delete file") }
                    }.show()
            }, marginParams(7))
            root.second.addView(row, marginParams(bottom = 10))
        }
        root.second.addView(actionButton("‹ Back to Home", purple, panel2) { showHome() }, marginParams(bottom = 12))
        setContentView(root.first)
    }

    private fun runScript(file: java.io.File) {
        if (runningProcesses.containsKey(file.name)) {
            showInfo("Already running", "${file.name} is already running. Use the red Stop button first.")
            return
        }
        val ext = file.extension.lowercase()
        val candidates = when (ext) {
            "py" -> listOf("python3", "python")
            "js" -> listOf("node", "nodejs")
            "sh" -> listOf("sh")
            else -> { showInfo("Unsupported file", "Run supports .py, .js and .sh files. Python and Node.js executables must be installed in the app environment."); return }
        }
        Thread {
            var process: Process? = null
            var lastError = "Runtime executable not found"
            for (exe in candidates) {
                try { process = ProcessBuilder(exe, file.absolutePath).directory(scriptsDir).redirectErrorStream(true).start(); break }
                catch (e: Exception) { lastError = e.message ?: lastError }
            }
            if (process == null) {
                runOnUiThread { showInfo("Runtime unavailable", "Could not start ${file.name}. This Android build does not bundle Python/Node.js, and the executable was not found. Details: $lastError") }
                return@Thread
            }
            val proc = process
            runningProcesses[file.name] = proc
            val log = StringBuilder("Starting ${file.name}\n")
            runLogs[file.name] = log
            try {
                proc.inputStream.bufferedReader().useLines { lines -> lines.forEach { line -> synchronized(log) { log.append(line).append('\n') } } }
                val code = proc.waitFor()
                synchronized(log) { log.append("\nProcess exited with code ").append(code).append('\n') }
            } catch (e: Exception) { synchronized(log) { log.append("\nError: ").append(e.message).append('\n') } }
            finally { runningProcesses.remove(file.name); runOnUiThread { Toast.makeText(this, "${file.name} finished", Toast.LENGTH_SHORT).show() } }
        }.start()
        showInfo("Run requested", "Trying to start ${file.name}. If the Python/Node.js runtime is not available, the app will show a runtime error. Check Output for logs.")
    }

    private fun stopScript(file: java.io.File) {
        val process = runningProcesses.remove(file.name)
        if (process == null) { showInfo("Not running", "${file.name} is not currently running."); return }
        process.destroy()
        Thread { try { if (!process.waitFor(700, java.util.concurrent.TimeUnit.MILLISECONDS)) process.destroyForcibly() } catch (_: Exception) { process.destroyForcibly() } }.start()
        runLogs[file.name]?.let { synchronized(it) { it.append("\nStopped by user.\n") } }
        Toast.makeText(this, "Stopped ${file.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showScriptOutput(file: java.io.File) {
        val log = runLogs[file.name]
        val output = if (log == null) "No output yet. Tap Run to try launching this file." else synchronized(log) { log.toString() }
        android.app.AlertDialog.Builder(this).setTitle(file.name + " • Output").setMessage(output.takeLast(12000))
            .setPositiveButton("Refresh") { _, _ -> showScriptOutput(file) }.setNegativeButton("Close", null).show()
    }

    private fun screenRoot(title: String, subtitle: String): Pair<LinearLayout, LinearLayout> {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(20)) }
        page.addView(label("𝐒ᴄʀʏHost", 26f, Color.WHITE).apply { typeface = Typeface.create("serif", Typeface.BOLD_ITALIC) })
        page.addView(label(title, 22f, cyan).apply { setPadding(0, dp(12), 0, dp(3)) })
        page.addView(label(subtitle, 12f, muted).apply { setPadding(0, 0, 0, dp(18)) })
        scroll.addView(page); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return Pair(root, page)
    }

    private fun createScriptDialog() {
        val input = EditText(this).apply { hint = "example.py"; setSingleLine(true); setText("script.py") }
        android.app.AlertDialog.Builder(this).setTitle("Create a script").setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim().replace(Regex("[^A-Za-z0-9._-]"), "_")
                val ext = name.substringAfterLast('.', "").lowercase()
                if (name.isBlank() || name.startsWith(".") || ext !in setOf("py", "js", "sh", "txt")) {
                    showInfo("Invalid filename", "Use a filename ending in .py, .js, .sh or .txt.")
                } else try {
                    val file = java.io.File(scriptsDir, name).canonicalFile
                    require(file.parentFile == scriptsDir.canonicalFile) { "Invalid file path" }
                    if (file.exists()) { showInfo("Already exists", "${file.name} already exists. Choose another name."); return@setPositiveButton }
                    file.writeText(when (ext) {
                        "py" -> "# ScryHost Python script\nprint(\"Hello from ScryHost!\")\n"
                        "js" -> "// ScryHost Node.js script\nconsole.log('Hello from ScryHost!');\n"
                        "sh" -> "#!/system/bin/sh\necho 'Hello from ScryHost!'\n"
                        else -> ""
                    })
                    editScriptDialog(file)
                } catch (e: Exception) { showInfo("Error", e.message ?: "Could not create file.") }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun editScriptDialog(file: java.io.File) {
        if (!file.exists() || !file.isFile) { showInfo("File unavailable", "This script no longer exists."); showScripts(); return }
        val editor = EditText(this).apply {
            setText(try { file.readText() } catch (e: Exception) { "" })
            setTextColor(Color.WHITE); setHintTextColor(muted); textSize = 13f
            gravity = Gravity.TOP or Gravity.START; minLines = 12
            background = rounded(Color.rgb(2, 8, 16), 12, Color.rgb(42, 63, 88))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val scroll = ScrollView(this).apply { addView(editor) }
        android.app.AlertDialog.Builder(this).setTitle("Edit ${file.name}").setView(scroll)
            .setPositiveButton("Save") { _, _ ->
                try {
                    editor.text.toString().let { content ->
                        require(content.length <= 1_000_000) { "File is too large (maximum 1 MB for editor)." }
                        file.writeText(content)
                    }
                    Toast.makeText(this, "Saved ${file.name}", Toast.LENGTH_SHORT).show()
                    showScripts()
                } catch (e: Exception) { showInfo("Save failed", e.message ?: "Could not save script") }
            }.setNeutralButton("Run") { _, _ ->
                try { file.writeText(editor.text.toString()); runScript(file) }
                catch (e: Exception) { showInfo("Save failed", e.message ?: "Could not save script") }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showTerminal() {
        val (root, page) = screenRoot("Terminal", "Local Android shell • commands run inside the app context")
        val output = TextView(this).apply {
            text = terminalHistory.toString().takeLast(12000)
            textSize = 12f; setTextColor(Color.rgb(190, 239, 209)); setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(2, 8, 16), 12, Color.rgb(42, 63, 88))
        }
        val outputScroll = ScrollView(this).apply { addView(output) }
        page.addView(outputScroll, LinearLayout.LayoutParams(-1, dp(280)))
        val input = EditText(this).apply { hint = "Type command, e.g. help, pwd, ls"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted); background = rounded(panel2, 12, Color.rgb(42, 63, 88)); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        page.addView(input, marginParams(bottom = 8))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(actionButton("▶ Execute", green, Color.rgb(4, 39, 39)) {
            val command = input.text.toString().trim()
            if (command.isNotBlank()) {
                input.setText("")
                if (command == "clear") terminalHistory.clear()
                if (command in listOf("help", "pwd", "ls", "clear") || command.startsWith("cat ")) {
                    val result = when {
                        command == "help" -> "Built-ins: help, pwd, ls, cat <filename>, clear. Other commands are passed to Android /system/bin/sh. Python/Node require a runtime."
                        command == "pwd" -> scriptsDir.absolutePath
                        command == "ls" -> (scriptsDir.list()?.joinToString("\n") ?: "").ifBlank { "(empty)" }
                        command == "clear" -> "Console cleared"
                        else -> { val f = java.io.File(scriptsDir, command.removePrefix("cat ").trim()); if (f.canonicalFile.parentFile == scriptsDir.canonicalFile && f.isFile) try { f.readText().take(8000) } catch (e: Exception) { e.message ?: "Read error" } else "File not found" }
                    }
                    terminalHistory.append("\n$ ").append(command).append("\n").append(result).append('\n')
                    output.text = terminalHistory.toString().takeLast(12000)
                } else {
                    terminalHistory.append("\n$ ").append(command).append("\n")
                    output.text = terminalHistory.toString().takeLast(12000)
                    Thread {
                        try {
                            val proc = ProcessBuilder("/system/bin/sh", "-c", command).directory(scriptsDir).redirectErrorStream(true).start()
                            val text = proc.inputStream.bufferedReader().use { it.readText() }.take(8000)
                            val code = proc.waitFor()
                            runOnUiThread {
                                terminalHistory.append(text).append("\n[exit ").append(code).append("]\n")
                                runLogs["terminal"] = StringBuilder(terminalHistory.toString().takeLast(12000))
                                output.text = terminalHistory.toString().takeLast(12000)
                            }
                        } catch (e: Exception) { runOnUiThread { terminalHistory.append("Command error: ").append(e.message).append('\n'); output.text = terminalHistory.toString().takeLast(12000) } }
                    }.start()
                }
            }
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        buttons.addView(actionButton("Clear", Color.rgb(255, 118, 192), Color.rgb(48, 15, 37)) { terminalHistory.clear(); output.text = "ScryHost local terminal\n" }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) })
        page.addView(buttons, marginParams(bottom = 12))
        page.addView(actionButton("‹ Back to Home", purple, panel2) { showHome() }, marginParams(bottom = 12))
        setContentView(root)
    }

    private fun showPackages() {
        val (root, page) = screenRoot("Packages", "Check available runtimes and install Python packages when pip exists")
        val python = findExecutable(listOf("python3", "python"))
        val node = findExecutable(listOf("node", "nodejs"))
        page.addView(card().apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(label("Python: ${python ?: "Not installed"}", 14f, if (python == null) Color.rgb(255,145,169) else green))
            addView(label("Node.js: ${node ?: "Not installed"}", 14f, if (node == null) Color.rgb(255,145,169) else green).apply { setPadding(0, dp(8), 0, 0) })
            addView(label("Packages can only be installed if a compatible runtime and pip are present in this app environment.", 11f, muted).apply { setPadding(0, dp(8), 0, 0) })
        }, marginParams(bottom = 12))
        val packageName = EditText(this).apply { hint = "Package name (e.g. requests)"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted); background = rounded(panel2, 12, Color.rgb(42,63,88)); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        page.addView(packageName, marginParams(bottom = 8))
        page.addView(actionButton("Install with pip", green, Color.rgb(4,39,39)) {
            val name = packageName.text.toString().trim()
            if (!name.matches(Regex("[A-Za-z0-9_.-]+"))) { showInfo("Package name", "Enter a valid package name."); return@actionButton }
            val py = findExecutable(listOf("python3", "python"))
            if (py == null) { showInfo("Runtime unavailable", "Python/pip is not installed or bundled in this app. Package installation cannot run until a runtime is added."); return@actionButton }
            Thread {
                try {
                    val proc = ProcessBuilder(py, "-m", "pip", "install", name).directory(scriptsDir).redirectErrorStream(true).start()
                    val result = proc.inputStream.bufferedReader().use { it.readText() }.takeLast(10000)
                    val code = proc.waitFor()
                    runLogs["packages"] = StringBuilder("pip install $name\n$result\nExit code: $code")
                    runOnUiThread { showInfo("pip result", result.takeLast(5000).ifBlank { "No output" } + "\nExit code: $code") }
                } catch (e: Exception) { runOnUiThread { showInfo("Install failed", e.message ?: "pip command failed") } }
            }.start()
        }, marginParams(bottom = 12))
        page.addView(actionButton("‹ Back to Home", purple, panel2) { showHome() })
        setContentView(root)
    }

    private fun findExecutable(names: List<String>): String? {
        val path = System.getenv("PATH") ?: return null
        for (dir in path.split(java.io.File.pathSeparator)) for (name in names) {
            val candidate = java.io.File(dir, name)
            if (candidate.isFile && candidate.canExecute()) return candidate.absolutePath
        }
        return null
    }

    private fun showLogs() {
        val (root, page) = screenRoot("Logs", "Recent terminal commands and script output/error history")
        val all = StringBuilder(terminalHistory)
        runLogs.entries.sortedBy { it.key }.forEach { (name, log) ->
            all.append("\n\n===== ").append(name).append(" =====\n")
            synchronized(log) { all.append(log.toString()) }
        }
        page.addView(TextView(this).apply {
            text = all.toString().takeLast(30000).ifBlank { "No logs yet. Run a script or execute a terminal command first." }
            textSize = 12f; setTextColor(Color.rgb(190,239,209)); setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(2,8,16), 12, Color.rgb(42,63,88))
        }, marginParams(bottom = 12))
        page.addView(actionButton("↻ Refresh logs", cyan, Color.rgb(8,34,50)) { showLogs() }, marginParams(bottom = 8))
        page.addView(actionButton("Clear logs", Color.rgb(255,118,192), Color.rgb(48,15,37)) {
            terminalHistory.clear(); terminalHistory.append("ScryHost local console\nType help for commands.\n"); runLogs.clear(); showLogs()
        }, marginParams(bottom = 8))
        page.addView(actionButton("‹ Back to Home", purple, panel2) { showHome() })
        setContentView(root)
    }

    private fun showSettings() {
        val options = arrayOf("Keep screen awake while app is open", "Start background service", "Stop background service", "Open Android app settings")
        android.app.AlertDialog.Builder(this).setTitle("ScryHost Settings").setItems(options) { _, which ->
            when (which) {
                0 -> {
                    val enabled = !window.decorView.keepScreenOn
                    window.decorView.keepScreenOn = enabled
                    getSharedPreferences("scryhost", MODE_PRIVATE).edit().putBoolean("keep_screen_on", enabled).apply()
                    showInfo("Settings", if (enabled) "Keep screen awake is enabled for this screen." else "Keep screen awake is disabled.")
                }
                1 -> startHostService()
                2 -> stopHostService()
                3 -> try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))) } catch (e: Exception) { showInfo("Settings", e.message ?: "Could not open Android settings") }
            }
        }.setNegativeButton("Close", null).show()
    }

    private fun showKeepAlive() {
        android.app.AlertDialog.Builder(this).setTitle("Keep Alive")
            .setMessage("Run ScryHost's foreground service with a persistent notification. Android battery rules can still limit background work; this does not install Python or Node.js runtimes.")
            .setPositiveButton("Start service") { _, _ -> startHostService() }
            .setNegativeButton("Stop service") { _, _ -> stopHostService() }
            .setNeutralButton("Battery settings") { _, _ -> try { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { showInfo("Battery settings", "Open this app's battery settings from Android Settings.") } }.show()
    }

    private fun startHostService() {
        try {
            val intent = Intent(this, HostService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            serviceRunning = true
            Toast.makeText(this, "Foreground service start requested", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { showInfo("Service error", e.message ?: "Could not start service") }
    }

    private fun stopHostService() {
        stopService(Intent(this, HostService::class.java)); serviceRunning = false
        Toast.makeText(this, "Foreground service stopped", Toast.LENGTH_SHORT).show()
    }

    private fun runPingCheck() {
        Toast.makeText(this, "Checking internet connection…", Toast.LENGTH_SHORT).show()
        Thread {
            val started = System.currentTimeMillis()
            try {
                val connection = java.net.URL("https://www.google.com/generate_204").openConnection() as java.net.HttpURLConnection
                connection.connectTimeout = 5000; connection.readTimeout = 5000; connection.instanceFollowRedirects = false
                val code = connection.responseCode; connection.disconnect()
                val ms = System.currentTimeMillis() - started
                runOnUiThread { showInfo("Ping Check", "Internet check completed. HTTP $code in ${ms}ms.") }
            } catch (e: Exception) { runOnUiThread { showInfo("Ping Check", "Connection failed: ${e.message ?: "No internet access"}") } }
        }.start()
    }

    private fun showInfo(title: String, message: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle("𝐒ᴄʀʏHost • $title")
            .setMessage(message)
            .setPositiveButton("Got it", null)
            .show()
    }

    private fun card(gradOrientation: GradientDrawable.Orientation? = null, colors: IntArray? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = if (colors != null && gradOrientation != null) GradientDrawable(gradOrientation, colors).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.rgb(61, 72, 121)) } else rounded(panel, 18, Color.rgb(34, 48, 82))
    }

    private fun metric(value: String, caption: String, accent: Int): LinearLayout = card().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), dp(9), dp(7), dp(8))
        addView(label(value, if (value.length > 5) 13f else 18f, accent))
        addView(label(caption, 9f, muted).apply { setPadding(0, dp(4), 0, 0) })
    }

    private fun tile(icon: String, title: String, subtitle: String, accent: Int, click: () -> Unit): LinearLayout = card().apply {
        setPadding(dp(12), dp(10), dp(10), dp(8))
        addView(label(icon, 22f, accent))
        addView(label(title, 15f, Color.WHITE).apply { setPadding(0, dp(4), 0, dp(2)) })
        addView(label(subtitle, 10f, muted))
        setOnClickListener { click() }
    }

    private fun scriptRow(icon: String, name: String, detail: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(11), dp(4), dp(11))
        addView(TextView(this@MainActivity).apply {
            text = icon; textSize = 17f; gravity = Gravity.CENTER; setTextColor(accent)
            background = rounded(Color.rgb(23, 34, 64), 12, Color.rgb(47, 60, 98))
            setPadding(dp(9), dp(8), dp(9), dp(8))
        })
        val texts = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
            addView(label(name, 13f, Color.WHITE))
            addView(label(detail, 10f, muted).apply { setPadding(0, dp(3), 0, 0) })
        }
        addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label("›", 24f, accent))
    }

    private fun sectionTitle(text: String, icon: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(label(text, 12f, muted), LinearLayout.LayoutParams(0, -2, 1f))
        addView(label(icon, 18f, purple))
    }

    private fun actionButton(text: String, stroke: Int, fill: Int, click: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(stroke)
        background = rounded(fill, 16, stroke)
        setOnClickListener { click() }
    }

    private fun label(text: String, size: Float, color: Int): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }

    private fun pill(color: Int, stroke: Int) = rounded(color, 30, stroke)
    private fun separator(): View = View(this).apply { setBackgroundColor(Color.rgb(29, 42, 70)); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) }
    private fun marginParams(bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
