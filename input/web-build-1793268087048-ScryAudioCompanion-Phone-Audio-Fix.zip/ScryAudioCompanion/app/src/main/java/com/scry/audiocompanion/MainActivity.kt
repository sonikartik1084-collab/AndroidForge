package com.scry.audiocompanion

import android.app.Activity
import android.content.Intent
import android.media.MediaPlayer
import android.media.audiofx.EnvironmentalReverb
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 24, 45)
    private val panel = Color.rgb(31, 43, 64)
    private val cyan = Color.rgb(48, 190, 244)
    private val teal = Color.rgb(0, 160, 145)
    private var player: MediaPlayer? = null
    private var reverb: EnvironmentalReverb? = null
    private var eq: Equalizer? = null
    private var loudness: LoudnessEnhancer? = null
    private var trackUri: Uri? = null
    private lateinit var audioStatus: TextView
    private lateinit var songStatus: TextView
    private lateinit var playButton: Button
    private var echoValue = 0
    private var volumeValue = 50
    private var mixValue = 100
    private val pickAudio = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun rounded(color: Int, radius: Float = 26f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(text: String, color: Int, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 15f; setTextColor(Color.WHITE); background = rounded(color, 24f)
        isAllCaps = false; setPadding(18, 12, 18, 12); setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 22, 22, 28); setBackgroundColor(bg) }
        root.addView(label("🎧  Scry Audio Pro", 30f, cyan, true), LinearLayout.LayoutParams(-1, 76))
        root.addView(label("Phone audio player • No microphone input", 13f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 30))
        root.addView(sliderCard("🔁  Echo / Reverb (0–100)", echoValue) { value -> echoValue = value; applyEffects() })
        root.addView(sliderCard("🔊  Volume Boost (0–100)", volumeValue) { value -> volumeValue = value; applyEffects() })
        root.addView(sliderCard("🎚️  Mix / Output Volume (0–100)", mixValue) { value -> mixValue = value; player?.setVolume(mixValue / 100f, mixValue / 100f) })
        val audioCard = card()
        audioStatus = label("🔈 Choose an audio file; sound plays from this phone", 16f, Color.WHITE)
        audioCard.addView(audioStatus, LinearLayout.LayoutParams(-1, 58))
        audioCard.addView(button("✓  PHONE AUDIO OUTPUT", cyan) { audioStatus.text = if (player != null) "🔊 Audio player ready — output is from phone" else "ℹ️ Choose music below to play through phone" }, LinearLayout.LayoutParams(-1, 54))
        root.addView(audioCard)

        val music = card()
        music.addView(label("🎶  Music Player", 19f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 52))
        songStatus = label("Choose an audio file to begin", 14f, Color.LTGRAY)
        music.addView(songStatus, LinearLayout.LayoutParams(-1, 44))
        music.addView(button("＋  CHOOSE MUSIC", teal) { chooseMusic() }, LinearLayout.LayoutParams(-1, 52))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 10, 0, 0) }
        controls.addView(button("|◀ PREVIOUS", Color.LTGRAY) { seekRelative(-15000) }.apply { setTextColor(Color.BLACK); textSize = 12f }, LinearLayout.LayoutParams(0, 50, 1f))
        controls.addView(button("▶ PLAY", Color.LTGRAY) { togglePlay() }.apply { setTextColor(Color.BLACK); textSize = 12f }.also { playButton = it }, LinearLayout.LayoutParams(0, 50, 1f))
        controls.addView(button("NEXT ▶|", Color.LTGRAY) { seekRelative(15000) }.apply { setTextColor(Color.BLACK); textSize = 12f }, LinearLayout.LayoutParams(0, 50, 1f))
        music.addView(controls); root.addView(music)
        root.addView(label("Effects apply to audio played inside this app. Android does not let a normal app change all phone audio or Telegram call audio globally.", 12f, Color.LTGRAY).apply { setPadding(4, 18, 4, 8) })
        scroll.addView(root); setContentView(scroll)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 18); background = rounded(panel, 28f)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 14, 0, 14); layoutParams = lp
    }

    private fun sliderCard(title: String, initial: Int, changed: (Int) -> Unit): LinearLayout {
        val box = card()
        box.addView(label(title, 17f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 42))
        val seek = SeekBar(this).apply { max = 100; progress = initial; progressTintList = android.content.res.ColorStateList.valueOf(teal); thumbTintList = android.content.res.ColorStateList.valueOf(teal) }
        box.addView(seek, LinearLayout.LayoutParams(-1, 42))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) { changed(progress) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return box
    }

    private fun chooseMusic() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*" }
        startActivityForResult(intent, pickAudio)
    }

    @Deprecated("Deprecated in Android API but works for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickAudio && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            trackUri = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            loadTrack(uri)
        }
    }

    private fun loadTrack(uri: Uri) {
        try {
            player?.release(); releaseEffects()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { mp ->
                    songStatus.text = "♪ ${uri.lastPathSegment ?: "Audio ready"}"
                    mp.setVolume(mixValue / 100f, mixValue / 100f)
                    attachEffects(mp.audioSessionId); mp.start(); playButton.text = "❚❚ PAUSE"; audioStatus.text = "🔊 Playing through phone speaker / selected output"
                }
                setOnCompletionListener { playButton.text = "▶ PLAY" }
                prepareAsync()
            }
            songStatus.text = "Loading audio…"
        } catch (e: Exception) { songStatus.text = "Could not open audio file" }
    }

    private fun togglePlay() {
        val mp = player
        if (mp == null) { chooseMusic(); return }
        try { if (mp.isPlaying) { mp.pause(); playButton.text = "▶ PLAY" } else { mp.start(); playButton.text = "❚❚ PAUSE" } } catch (_: Exception) {}
    }
    private fun seekRelative(ms: Int) { try { val mp = player ?: run { chooseMusic(); return }; mp.seekTo((mp.currentPosition + ms).coerceIn(0, mp.duration)) } catch (_: Exception) {} }

    private fun attachEffects(session: Int) {
        try { reverb = EnvironmentalReverb(0, session).apply {
            roomLevel = (-9000 + (echoValue * 90)).toShort()
            reverbLevel = (-9000 + (echoValue * 90)).toShort()
            decayTime = 1200 + echoValue * 35
            enabled = echoValue > 0
        } } catch (_: Exception) {}
        try { eq = Equalizer(0, session).apply { enabled = true; val range = bandLevelRange; val target = (range[0] + (range[1] - range[0]) * 55 / 100).toShort(); for (i in 0 until numberOfBands) setBandLevel(i.toShort(), target) } } catch (_: Exception) {}
        try { loudness = LoudnessEnhancer(session).apply { setTargetGain((volumeValue * 100).coerceIn(0, 10000)); enabled = true } } catch (_: Exception) {}
    }
    private fun applyEffects() {
        try { loudness?.setTargetGain((volumeValue * 100).coerceIn(0, 10000)) } catch (_: Exception) {}
        try { reverb?.let { effect -> effect.roomLevel = (-9000 + echoValue * 90).toShort(); effect.reverbLevel = (-9000 + echoValue * 90).toShort(); effect.decayTime = 1200 + echoValue * 35; effect.enabled = echoValue > 0 } } catch (_: Exception) {}
    }
    private fun releaseEffects() { try { reverb?.release() } catch (_: Exception) {}; try { eq?.release() } catch (_: Exception) {}; try { loudness?.release() } catch (_: Exception) {}; reverb = null; eq = null; loudness = null }
    override fun onDestroy() { try { player?.release() } catch (_: Exception) {}; releaseEffects(); super.onDestroy() }
}
