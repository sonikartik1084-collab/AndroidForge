# ScryHost — Android Studio project (logo updated)

This is an Android Studio Kotlin project for the ScryHost interface. The launcher icon now uses the photo supplied by the user.

## Currently implemented
- Dark ScryHost dashboard and navigation
- Android system document picker for importing files into app-private storage
- Create/list scripts in app-private storage
- Local file-console commands: `help`, `pwd`, `ls`, `cat <filename>`, `clear`
- Foreground service scaffold with Start/Stop controls
- Launcher icon derived from the supplied image

## Not yet a complete hosting runtime
This source is not honestly described as a fully working Python/Node hosting app. Python 3, Node.js, `pip` package installation, actual script process execution, Telegram bot heartbeat, full live stdout/stderr logs, per-script crash recovery, and robust 20-script orchestration are not implemented or verified. The terminal is a restricted app-local file console, not a device-wide shell. Android battery restrictions can also affect background execution.

## Build
1. Open `PocketPythonHost` in Android Studio with Android SDK Platform 35 and a JDK 17 installation.
2. Sync Gradle.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

No compiled APK is included because this environment does not have a verified Android Gradle build setup.
