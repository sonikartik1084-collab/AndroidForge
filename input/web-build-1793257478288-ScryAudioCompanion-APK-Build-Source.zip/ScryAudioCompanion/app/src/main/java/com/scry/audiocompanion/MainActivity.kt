package com.scry.audiocompanion

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import kotlin.concurrent.thread
import kotlin.math.abs

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 24, 45)
    private val panel = Color.rgb(31, 43, 64)
    private val cyan = Color.rgb(48, 190, 244)
    private val teal = Color.rgb(0, 160, 145)
    private var player: MediaPlayer? = null
    private var bass: BassBoost? = null
    private var eq: Equalizer? = null
    private var loudness: LoudnessEnhancer? = null
    private var trackUri: Uri? = null
    private var recording = false
    private var recorder: AudioRecord? = null
    private var micThread: Thread? = null
    private lateinit var micStatus: TextView
    private lateinit var songStatus: TextView
    private lateinit var playButton: Button
    private var volumeValue = 50
    private var bassValue = 50
    private var mixValue = 60
    private val pickAudio = 101
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun rounded(color: Int, radius: Float = 26f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(text: String, color: Int, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 15f; setTextColor(Color.WHITE); background = rounded(color, 24f)
        isAllCaps = false; setPadding(18, 12, 18, 12); setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 22, 22, 28); setBackgroundColor(bg) }
        root.addView(label("🎙️  Mic P Pro", 30f, cyan, true), LinearLayout.LayoutParams(-1, 76))
        root.addView(label("Audio controls • Scry", 13f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 30))
        root.addView(sliderCard("🔊  Volume Boost", volumeValue) { value -> volumeValue = value; applyEffects() })
        root.addView(sliderCard("♫  Bass Level", bassValue) { value -> bassValue = value; applyEffects() })
        root.addView(sliderCard("🎚️  Mix Level", mixValue) { value -> mixValue = value; player?.setVolume(mixValue / 100f, mixValue / 100f) })
        val micCard = card()
        micStatus = label("🎤 Mic is stopped", 17f, Color.WHITE)
        micCard.addView(micStatus, LinearLayout.LayoutParams(-1, 54))
        micCard.addView(button("▶  START MIC", cyan) { toggleMic() }, LinearLayout.LayoutParams(-1, 58))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 12, 0, 0) }
        row.addView(button("YES ✅", Color.rgb(22, 155, 75)) { micStatus.text = if (recording) "✅ Microphone permission and input active" else "ℹ️ Start Mic to test input" }, LinearLayout.LayoutParams(0, 52, 1f))
        val gap = View(this); row.addView(gap, LinearLayout.LayoutParams(10, 1))
        row.addView(button("NO ❌", Color.rgb(215, 38, 43)) { micStatus.text = "❌ Mic test not confirmed" }, LinearLayout.LayoutParams(0, 52, 1f))
        micCard.addView(row); root.addView(micCard)

        val music = card()
        music.addView(label("🎶  Music Player", 19f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 52))
        songStatus = label("Choose an audio file to begin", 14f, Color.LTGRAY)
        music.addView(songStatus, LinearLayout.LayoutParams(-1, 44))
        music.addView(button("＋  CHOOSE MUSIC", teal) { chooseMusic() }, LinearLayout.LayoutParams(-1, 52))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 10, 0, 0) }
        controls.addView(button("|◀ PREVIOUS", Color.LTGRAY) { seekRelative(-15000) }.apply { setTextColor(Color.BLACK); textSize = 12f }, LinearLayout.LayoutParams(0, 50, 1f))
        controls.addView(button("▶ PLAY", Color.LTGRAY) { togglePlay() }.apply { setTextColor(Color.BLACK); textSize = 12f }.also { playButton = it }, LinearLayout.LayoutParams(0, 50, 1f))
        controls.addView(button("NEXT ▶|", Color.LTGRAY) { seekRelative(15000) }.apply { setTextColor(Color.BLACK); textSize = 12f }, LinearLayout.LayoutParams(0, 50, 1f))
        music.addView(controls); root.addView(music)
        root.addView(label("Note: audio effects apply to this app's music player. They cannot be injected into Telegram calls by a normal Android app.", 12f, Color.LTGRAY).apply { setPadding(4, 18, 4, 8) })
        scroll.addView(root); setContentView(scroll)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 18); background = rounded(panel, 28f)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 14, 0, 14); layoutParams = lp
    }

    private fun sliderCard(title: String, initial: Int, changed: (Int) -> Unit): LinearLayout {
        val box = card()
        box.addView(label(title, 17f, Color.LTGRAY), LinearLayout.LayoutParams(-1, 42))
        val seek = SeekBar(this).apply { max = 100; progress = initial; progressTintList = android.content.res.ColorStateList.valueOf(teal); thumbTintList = android.content.res.ColorStateList.valueOf(teal) }
        box.addView(seek, LinearLayout.LayoutParams(-1, 42))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) { changed(progress) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return box
    }

    private fun chooseMusic() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*" }
        startActivityForResult(intent, pickAudio)
    }

    @Deprecated("Deprecated in Android API but works for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickAudio && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            trackUri = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            loadTrack(uri)
        }
    }

    private fun loadTrack(uri: Uri) {
        try {
            player?.release(); releaseEffects()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { mp ->
                    songStatus.text = "♪ ${uri.lastPathSegment ?: "Audio ready"}"
                    mp.setVolume(mixValue / 100f, mixValue / 100f)
                    attachEffects(mp.audioSessionId); mp.start(); playButton.text = "❚❚ PAUSE"
                }
                setOnCompletionListener { playButton.text = "▶ PLAY" }
                prepareAsync()
            }
            songStatus.text = "Loading audio…"
        } catch (e: Exception) { songStatus.text = "Could not open audio file" }
    }

    private fun togglePlay() {
        val mp = player
        if (mp == null) { chooseMusic(); return }
        try { if (mp.isPlaying) { mp.pause(); playButton.text = "▶ PLAY" } else { mp.start(); playButton.text = "❚❚ PAUSE" } } catch (_: Exception) {}
    }
    private fun seekRelative(ms: Int) { try { val mp = player ?: run { chooseMusic(); return }; mp.seekTo((mp.currentPosition + ms).coerceIn(0, mp.duration)) } catch (_: Exception) {} }

    private fun attachEffects(session: Int) {
        try { bass = BassBoost(0, session).apply { setEnabled(true) } } catch (_: Exception) {}
        try { eq = Equalizer(0, session).apply { enabled = true; val range = bandLevelRange; val target = (range[0] + (range[1] - range[0]) * bassValue / 100).toShort(); for (i in 0 until numberOfBands) setBandLevel(i.toShort(), target) } } catch (_: Exception) {}
        try { loudness = LoudnessEnhancer(session).apply { setTargetGain((volumeValue * 100).coerceIn(0, 10000)); enabled = true } } catch (_: Exception) {}
    }
    private fun applyEffects() {
        try { loudness?.setTargetGain((volumeValue * 100).coerceIn(0, 10000)) } catch (_: Exception) {}
        try { bass?.setStrength((bassValue * 10).coerceIn(0, 1000).toShort()) } catch (_: Exception) {}
        try { eq?.let { effect -> val r = effect.bandLevelRange; val v = (r[0] + (r[1] - r[0]) * bassValue / 100).toShort(); for (i in 0 until effect.numberOfBands) effect.setBandLevel(i.toShort(), v) } } catch (_: Exception) {}
    }
    private fun releaseEffects() { try { bass?.release() } catch (_: Exception) {}; try { eq?.release() } catch (_: Exception) {}; try { loudness?.release() } catch (_: Exception) {}; bass = null; eq = null; loudness = null }

    private fun toggleMic() {
        if (recording) { stopMic(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 22); return
        }
        startMic()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 22 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startMic()
        else micStatus.text = "Microphone permission not granted"
    }
    private fun startMic() {
        try {
            val rate = 16000
            val min = AudioRecord.getMinBufferSize(rate, android.media.AudioFormat.CHANNEL_IN_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) { micStatus.text = "Mic input unavailable on this device"; return }
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, rate, android.media.AudioFormat.CHANNEL_IN_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT, min * 2)
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) { micStatus.text = "Mic input could not start"; recorder?.release(); recorder = null; return }
            recorder?.startRecording(); recording = true; micStatus.text = "🎙️ Mic active • checking input…"
            micThread = thread(start = true) {
                val buffer = ShortArray(min / 2)
                while (recording) {
                    val count = try { recorder?.read(buffer, 0, buffer.size) ?: -1 } catch (_: Exception) { -1 }
                    if (count > 0) {
                        var peak = 0
                        for (i in 0 until count) peak = maxOf(peak, abs(buffer[i].toInt()))
                        val level = (peak * 100 / 32767).coerceIn(0, 100)
                        handler.post { if (recording) micStatus.text = "🎙️ Mic active • input level $level%" }
                    } else Thread.sleep(100)
                }
            }
        } catch (_: Exception) { micStatus.text = "Could not start microphone"; stopMic() }
    }
    private fun stopMic() {
        recording = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null; micThread = null; micStatus.text = "🎤 Mic is stopped"
    }
    override fun onDestroy() { stopMic(); try { player?.release() } catch (_: Exception) {}; releaseEffects(); super.onDestroy() }
}
