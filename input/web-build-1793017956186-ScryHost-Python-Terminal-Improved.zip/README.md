# ScryHost — Android Studio source project

This is a Kotlin Android app source project based on the ScryHost design. The launcher icon uses the user-provided photo.

## Functional UI and local features in this source
- Home dashboard and navigation to Scripts, Terminal, Packages and More
- System document picker to import files into the app-private scripts directory
- ZIP import with archive entries flattened to safe filenames
- List imported files, create scripts, edit/save script content, delete imported copies, run/stop process attempts, and view per-script output
- Local terminal page with command input, output, built-in `help`, `pwd`, `ls`, `cat <filename>`, `clear`, and Android app-context shell commands
- Runtime availability check and `pip install` attempt when a Python executable is present
- Settings for keep-screen-on, start/stop foreground service and Android app settings
- Keep Alive options, ping check, and combined logs view

## Runtime implementation and limitations
The app Gradle configuration uses Chaquopy to bundle Python 3.11 and Rhino to execute standard JavaScript files. Python scripts run in the embedded interpreter, and JS scripts run in Rhino. Rhino is **not Node.js**: Node built-ins (`require`, `fs`, `http`, etc.) and npm packages are not available. Python third-party packages must be added to the Chaquopy `pip` configuration at build time; the in-app Packages page explains this rather than pretending a system `pip` exists. Python Stop uses a trace-based stop marker; JS Stop uses Rhino instruction checks; shell scripts are stopped as processes. This source has not been compiled or device-tested in this environment. Android shell commands are restricted by the app sandbox and are not a full Linux terminal. Telegram bot hosting, persistent per-script supervision, restart-on-crash, and long-duration background execution have not been validated. Android battery and foreground-service policies may limit background work.

## Build
1. Open `PocketPythonHost` in Android Studio with Android SDK Platform 35 and JDK 17.
2. Sync Gradle.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

No APK is included because this environment has no verified Android Gradle build setup. Compile and test on a device before installing or relying on it.


## Python packages bundled at build time
The app Gradle file configures Chaquopy to download a starter set of common packages (Flask, aiohttp, requests, Telethon, python-telegram-bot, pyTelegramBotAPI, BeautifulSoup, and utilities) during Gradle Sync/build. `requirements-android.txt` mirrors this list for reference. This does **not** download every package on PyPI, and it does not mean packages are already inside this ZIP. The build needs internet access to fetch compatible package builds. Some packages may be unsupported or incompatible with Android/Chaquopy; if Gradle fails on a package, remove that package from both the Gradle pip block and requirements file and rebuild. Python packages are bundled into the APK, not installed dynamically by the in-app Packages screen.

Rhino remains a standard JavaScript engine, not Node.js; Python packages do not add Node built-ins or npm support. This project has not been built or tested in this environment.


## Build-failure fix included in this revision
- Added the missing Rhino Maven dependency (`org.mozilla:rhino:1.7.15`) required by the JavaScript imports in `MainActivity.kt`. Without it, Kotlin compilation fails with unresolved `org.mozilla.javascript` references.
- Kept the Chaquopy Python configuration and starter package list. Packages are resolved/downloaded during Gradle build; they are not pre-downloaded inside this ZIP.
- If the build still fails, open the failed GitHub Actions run, expand **Build project** / **Live log**, and share the first actual `FAILURE:` or `Could not find` / `No matching distribution` lines. The screenshot only shows the final failure status, not the root cause.

## Reliable APK build workflow
This revision adds `.github/workflows/android-apk.yml` and places the Android project files at the repository root. The workflow explicitly uses JDK 17, Android SDK 35, and Gradle 8.9 (compatible with Android Gradle Plugin 8.7.3), runs `assembleDebug`, lists the actual APK output paths, and uploads the APK plus diagnostics. This addresses the common mismatch where the Android build step succeeds but a separate artifact collector looks in the wrong folder.
To use it, push these files to a GitHub repository's `main` or `master` branch, or run the workflow manually from Actions. The APK is available in the workflow run's Artifacts section if the build succeeds. This workflow has not been executed from this environment, so successful compilation is not guaranteed.


## Build configuration correction (AndroidForge)

This revision uses Chaquopy's Kotlin-DSL configuration (`chaquopy { defaultConfig { ... } }`). The previous `python { ... }` block is the legacy form and can fail in `app/build.gradle.kts` with unresolved DSL references. It also pins `aiohttp==3.10.10`, for which Chaquopy publishes Android wheels compatible with Python 3.11, instead of allowing pip to select a newer version with no matching Android wheel.

For AndroidForge, upload this ZIP as the source ZIP in the AndroidForge web UI and start a new build. The workflow YAML inside a source ZIP is not what drives the AndroidForge service; AndroidForge's own `Build Android APK` workflow builds the uploaded project. If this still fails, download the `AndroidForge-logs` artifact because the status screen alone only shows the final wrapper error, not the underlying Gradle error.

This archive has been structurally checked, but it has not been compiled in this environment.


## Important runtime limits

This source ZIP includes a best-effort foreground keep-alive service with a partial wake lock. Android and phone-maker battery policies can still stop it; this is not guaranteed 24/7 cloud hosting. Script execution is still managed by MainActivity and is not guaranteed to survive app process death. Python scripts use embedded Chaquopy; JavaScript uses Rhino, not Node.js, so Node `require`, npm packages, and Node built-ins will not work. The Packages screen cannot dynamically install arbitrary pip packages after APK installation; add supported packages to `app/build.gradle.kts` and rebuild.


## Latest AndroidForge dependency compatibility fix
- Pinned `websockets==15.0.1` because the AndroidForge log showed pip selecting `websockets 17.3`, which requires Python >=3.11 while the build environment reported Python 3.10.12. The same pin is applied in `app/build.gradle.kts` and `requirements-android.txt`. This fixes the specific dependency error shown in the latest logs; a fresh build is still required to discover any subsequent issues.


## AndroidForge Python resolver compatibility fix (v4)
- The latest AndroidForge logs show the build-time resolver running Python 3.10.12 and selecting `soupsieve 3.0.4`, which requires Python >=3.11.5.
- Pinned `beautifulsoup4==4.13.4` and `soupsieve==2.7` in both the Chaquopy pip configuration and `requirements-android.txt` to avoid that specific resolver failure.
- ZIP integrity has been checked; this revision has not been compiled by AndroidForge from this environment. If another package fails, the next AndroidForge logs will show its exact requirement.


## Terminal improvement (v5)
The in-app terminal now routes `python -c`, `python <script.py>`, `pip list`, and `pip show <package>` through the embedded Chaquopy Python runtime. `pip install` is intentionally reported as build-time-only: this APK does not have a normal writable Linux/Pydroid environment. JavaScript remains Rhino (not Node.js). Android background execution is not guaranteed 24/7 by the phone OS.
