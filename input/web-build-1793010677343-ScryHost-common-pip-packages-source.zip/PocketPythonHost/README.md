# ScryHost — Android Studio source project

This is a Kotlin Android app source project based on the ScryHost design. The launcher icon uses the user-provided photo.

## Functional UI and local features in this source
- Home dashboard and navigation to Scripts, Terminal, Packages and More
- System document picker to import files into the app-private scripts directory
- ZIP import with archive entries flattened to safe filenames
- List imported files, create scripts, edit/save script content, delete imported copies, run/stop process attempts, and view per-script output
- Local terminal page with command input, output, built-in `help`, `pwd`, `ls`, `cat <filename>`, `clear`, and Android app-context shell commands
- Runtime availability check and `pip install` attempt when a Python executable is present
- Settings for keep-screen-on, start/stop foreground service and Android app settings
- Keep Alive options, ping check, and combined logs view

## Runtime implementation and limitations
The app Gradle configuration uses Chaquopy to bundle Python 3.11 and Rhino to execute standard JavaScript files. Python scripts run in the embedded interpreter, and JS scripts run in Rhino. Rhino is **not Node.js**: Node built-ins (`require`, `fs`, `http`, etc.) and npm packages are not available. Python third-party packages must be added to the Chaquopy `pip` configuration at build time; the in-app Packages page explains this rather than pretending a system `pip` exists. Python Stop uses a trace-based stop marker; JS Stop uses Rhino instruction checks; shell scripts are stopped as processes. This source has not been compiled or device-tested in this environment. Android shell commands are restricted by the app sandbox and are not a full Linux terminal. Telegram bot hosting, persistent per-script supervision, restart-on-crash, and long-duration background execution have not been validated. Android battery and foreground-service policies may limit background work.

## Build
1. Open `PocketPythonHost` in Android Studio with Android SDK Platform 35 and JDK 17.
2. Sync Gradle.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

No APK is included because this environment has no verified Android Gradle build setup. Compile and test on a device before installing or relying on it.


## Python packages bundled at build time
The app Gradle file configures Chaquopy to download a starter set of common packages (Flask, aiohttp, requests, Telethon, python-telegram-bot, pyTelegramBotAPI, BeautifulSoup, and utilities) during Gradle Sync/build. `requirements-android.txt` mirrors this list for reference. This does **not** download every package on PyPI, and it does not mean packages are already inside this ZIP. The build needs internet access to fetch compatible package builds. Some packages may be unsupported or incompatible with Android/Chaquopy; if Gradle fails on a package, remove that package from both the Gradle pip block and requirements file and rebuild. Python packages are bundled into the APK, not installed dynamically by the in-app Packages screen.

Rhino remains a standard JavaScript engine, not Node.js; Python packages do not add Node built-ins or npm support. This project has not been built or tested in this environment.
