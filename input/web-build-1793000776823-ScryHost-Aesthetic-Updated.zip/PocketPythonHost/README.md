# 𝐒ᴄʀʏHost — Aesthetic Android Studio ZIP

A dark navy / violet / cyan Android UI starter inspired by the selected ScryHost mockup. Branding uses the requested `𝐒ᴄʀʏ` style throughout the visible app title and key labels.

## Included UI options
- Home dashboard and service status
- Start Service / Stop Service
- Restart All (restarts the foreground service scaffold only)
- Ping Check (currently an explanatory placeholder; no real Telegram ping is sent)
- Scripts, Terminal, Packages, Settings
- Files, Logs, Add Script, Keep Alive option cards
- Recent example `.py` and `.js` script rows
- Foreground service and boot receiver scaffolds
- Design preview image

## Important limitations
This is **not a finished hosting app and is not a compiled APK**. The project has not been built or tested here. The buttons and labels are a UI starter; the Python 3.13 runtime, pip installer, Node.js runtime, actual `.py`/`.js` execution, file picker/upload, live terminal output, persistent logs, true Telegram ping/heartbeat, restart-on-crash per script, and 20-process manager are **not implemented**. `Restart All` currently restarts only the foreground service scaffold, not scripts.

## Build on a computer
1. Open the extracted folder in Android Studio.
2. Let Gradle sync complete.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

## Background notes
A foreground service can improve persistence while the screen is off, but Android/OEM battery management may still stop it. A powered-off phone cannot run local scripts. Keep Telegram bot tokens private.
