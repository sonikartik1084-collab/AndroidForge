package com.example.pocketpythonhost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 9, 22)
    private val panel = Color.rgb(12, 20, 42)
    private val panel2 = Color.rgb(16, 28, 54)
    private val purple = Color.rgb(160, 86, 255)
    private val cyan = Color.rgb(45, 220, 235)
    private val green = Color.rgb(50, 232, 163)
    private val muted = Color.rgb(156, 174, 204)
    private var serviceRunning = false
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "𝐒ᴄʀʏHost"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD_ITALIC)
        }
        val owner = TextView(this).apply {
            text = "♛  OWNER"
            textSize = 11f
            setTextColor(Color.rgb(255, 194, 94))
            background = pill(Color.rgb(55, 38, 58), Color.rgb(111, 76, 119))
            setPadding(dp(11), dp(7), dp(11), dp(7))
        }
        brandRow.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        brandRow.addView(owner)
        page.addView(brandRow)
        page.addView(label("PYTHON  •  NODE.JS  •  TELEGRAM", 11f, cyan).apply { setPadding(0, dp(3), 0, dp(16)) })

        val hero = card(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(35, 25, 76), Color.rgb(9, 44, 70)))
        hero.setPadding(dp(17), dp(17), dp(17), dp(17))
        hero.addView(label("✦  YOUR LITTLE HOSTING SPACE", 11f, muted))
        status = label(if (serviceRunning) "●  SERVICE RUNNING" else "●  READY TO START", 22f, if (serviceRunning) green else Color.WHITE)
        status.setPadding(0, dp(10), 0, dp(4))
        hero.addView(status)
        hero.addView(label("Keep your scripts organised, one place at a time.", 12f, muted))
        page.addView(hero, marginParams(bottom = 14))

        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metrics.addView(metric("20", "SCRIPT SLOTS", purple), LinearLayout.LayoutParams(0, dp(80), 1f))
        metrics.addView(metric("Python", "RUNTIME", cyan), LinearLayout.LayoutParams(0, dp(80), 1f).apply { leftMargin = dp(8) })
        metrics.addView(metric("Node.js", "RUNTIME", Color.rgb(255, 118, 192)), LinearLayout.LayoutParams(0, dp(80), 1f).apply { leftMargin = dp(8) })
        page.addView(metrics, marginParams(bottom = 14))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = actionButton("▶  Start Service", green, Color.rgb(4, 39, 39)) {
            val intent = Intent(this@MainActivity, HostService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            serviceRunning = true
            status.text = "●  SERVICE REQUESTED"
            status.setTextColor(green)
            Toast.makeText(this@MainActivity, "Background service start requested", Toast.LENGTH_SHORT).show()
        }
        val stop = actionButton("■  Stop Service", Color.rgb(255, 91, 133), Color.rgb(48, 15, 37)) {
            stopService(Intent(this@MainActivity, HostService::class.java))
            serviceRunning = false
            status.text = "●  SERVICE STOPPED"
            status.setTextColor(Color.rgb(255, 145, 169))
            Toast.makeText(this@MainActivity, "Background service stopped", Toast.LENGTH_SHORT).show()
        }
        actions.addView(start, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(stop, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(9) })
        page.addView(actions, marginParams(bottom = 10))

        val quickActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quickActions.addView(actionButton("↻  Restart All", purple, Color.rgb(31, 20, 58)) {
            stopService(Intent(this@MainActivity, HostService::class.java))
            val intent = Intent(this@MainActivity, HostService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            serviceRunning = true
            status.text = "●  SERVICE RESTART REQUESTED"
            status.setTextColor(cyan)
            Toast.makeText(this@MainActivity, "Service restart requested (scripts are not connected yet)", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        quickActions.addView(actionButton("♡  Ping Check", cyan, Color.rgb(8, 34, 50)) {
            showInfo("Ping Check", "UI option is ready. Real Telegram bot ping/heartbeat requires the Python/Node runtime and bot process to be integrated; this starter does not send a real ping yet.")
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(9) })
        page.addView(quickActions, marginParams(bottom = 22))

        page.addView(sectionTitle("YOUR WORKSPACE", "✧"), marginParams(bottom = 10))
        val grid1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid1.addView(tile("▣", "Scripts", "Manage .py & .js files", purple) { showInfo("Scripts", "Script manager UI preview. Actual Python/Node execution is not integrated yet.") }, LinearLayout.LayoutParams(0, dp(104), 1f))
        grid1.addView(tile("⌁", "Terminal", "Live logs & commands", cyan) { showInfo("Terminal", "Terminal screen preview. Live process output is not connected yet.") }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(10) })
        page.addView(grid1, marginParams(bottom = 10))
        val grid2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid2.addView(tile("⬡", "Packages", "pip modules", Color.rgb(255, 183, 90)) { showInfo("Packages", "Package manager preview. pip/runtime integration is not included yet.") }, LinearLayout.LayoutParams(0, dp(104), 1f))
        grid2.addView(tile("⚙", "Settings", "App & service settings", Color.rgb(255, 118, 192)) { showInfo("Settings", "Background service is a starter only; reboot and battery behaviour varies by device.") }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(10) })
        page.addView(grid2, marginParams(bottom = 10))
        val grid3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid3.addView(tile("▤", "Files", "Upload .py / .js / .zip", cyan) { showInfo("Files", "File browser/upload screen is planned. File picker and actual file management are not connected yet.") }, LinearLayout.LayoutParams(0, dp(104), 1f))
        grid3.addView(tile("◷", "Logs", "Output & error history", Color.rgb(255, 118, 192)) { showInfo("Logs", "Logs screen preview. Real script stdout/stderr and log saving need the runtime process manager.") }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(10) })
        page.addView(grid3, marginParams(bottom = 10))
        val grid4 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid4.addView(tile("⇧", "Add Script", "Choose or create file", Color.rgb(255, 183, 90)) { showInfo("Add Script", "Add-script screen planned for .py, .js, .json, .zip and .txt files. Upload controls are not wired up yet.") }, LinearLayout.LayoutParams(0, dp(104), 1f))
        grid4.addView(tile("♥", "Keep Alive", "Background options", green) { showInfo("Keep Alive", "Foreground-service scaffold is included. Android battery restrictions can still stop background work; no script process is running in this starter.") }, LinearLayout.LayoutParams(0, dp(104), 1f).apply { leftMargin = dp(10) })
        page.addView(grid4, marginParams(bottom = 18))

        page.addView(sectionTitle("RECENT SCRIPTS", "↗"), marginParams(bottom = 10))
        val list = card()
        list.setPadding(dp(12), dp(4), dp(12), dp(4))
        list.addView(scriptRow("✈", "telegram_bot.py", "Python  •  Tap to manage", green))
        list.addView(separator())
        list.addView(scriptRow("♫", "music_bot.py", "Python  •  Example entry", cyan))
        list.addView(separator())
        list.addView(scriptRow("JS", "server.js", "Node.js  •  Example entry", Color.rgb(255, 183, 90)))
        page.addView(list, marginParams(bottom = 14))
        page.addView(label("𝐒ᴄʀʏ  ×  #ᴠᴇɴᴏᴍ   ♡", 12f, purple).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(10)) })
        page.addView(label("Design preview • Runtime integration still required", 10f, muted).apply { gravity = Gravity.CENTER })

        scroll.addView(page)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = rounded(panel2, 22, Color.rgb(38, 54, 91))
        }
        listOf("⌂\nHome", "▣\nScripts", "⌁\nTerminal", "⬡\nPackages", "•••\nMore").forEachIndexed { index, item ->
            val t = TextView(this).apply {
                text = item
                gravity = Gravity.CENTER
                textSize = 11f
                setTextColor(if (index == 0) cyan else muted)
                setPadding(dp(5), dp(2), dp(5), dp(2))
                setOnClickListener { if (index != 0) showInfo(item.substringAfter('\n'), "${item.substringAfter('\n')} section preview. Full functionality will be added when the runtime and file manager are integrated.") }
            }
            nav.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(10)) })
        setContentView(root)
    }

    private fun showInfo(title: String, message: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle("𝐒ᴄʀʏHost • $title")
            .setMessage(message)
            .setPositiveButton("Got it", null)
            .show()
    }

    private fun card(gradOrientation: GradientDrawable.Orientation? = null, colors: IntArray? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = if (colors != null && gradOrientation != null) GradientDrawable(gradOrientation, colors).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.rgb(61, 72, 121)) } else rounded(panel, 18, Color.rgb(34, 48, 82))
    }

    private fun metric(value: String, caption: String, accent: Int): LinearLayout = card().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), dp(9), dp(7), dp(8))
        addView(label(value, if (value.length > 5) 13f else 18f, accent))
        addView(label(caption, 9f, muted).apply { setPadding(0, dp(4), 0, 0) })
    }

    private fun tile(icon: String, title: String, subtitle: String, accent: Int, click: () -> Unit): LinearLayout = card().apply {
        setPadding(dp(12), dp(10), dp(10), dp(8))
        addView(label(icon, 22f, accent))
        addView(label(title, 15f, Color.WHITE).apply { setPadding(0, dp(4), 0, dp(2)) })
        addView(label(subtitle, 10f, muted))
        setOnClickListener { click() }
    }

    private fun scriptRow(icon: String, name: String, detail: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(11), dp(4), dp(11))
        addView(TextView(this@MainActivity).apply {
            text = icon; textSize = 17f; gravity = Gravity.CENTER; setTextColor(accent)
            background = rounded(Color.rgb(23, 34, 64), 12, Color.rgb(47, 60, 98))
            setPadding(dp(9), dp(8), dp(9), dp(8))
        })
        val texts = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
            addView(label(name, 13f, Color.WHITE))
            addView(label(detail, 10f, muted).apply { setPadding(0, dp(3), 0, 0) })
        }
        addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label("›", 24f, accent))
    }

    private fun sectionTitle(text: String, icon: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(label(text, 12f, muted), LinearLayout.LayoutParams(0, -2, 1f))
        addView(label(icon, 18f, purple))
    }

    private fun actionButton(text: String, stroke: Int, fill: Int, click: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(stroke)
        background = rounded(fill, 16, stroke)
        setOnClickListener { click() }
    }

    private fun label(text: String, size: Float, color: Int): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
    }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }

    private fun pill(color: Int, stroke: Int) = rounded(color, 30, stroke)
    private fun separator(): View = View(this).apply { setBackgroundColor(Color.rgb(29, 42, 70)); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) }
    private fun marginParams(bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
