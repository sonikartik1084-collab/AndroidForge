plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

chaquopy {
    defaultConfig {
        version = "3.11"
        pip {
            // Pin aiohttp to a version with published Android wheels for Python 3.11.
            install("flask")
            install("aiohttp==3.10.10")
            install("requests")
            install("urllib3")
            install("python-telegram-bot")
            install("telethon")
            install("pyTelegramBotAPI==4.26.0")
            install("beautifulsoup4")
            install("python-dotenv")
            install("websockets")
            install("websocket-client")
            install("schedule")
            install("APScheduler")
            install("pytz")
            install("python-dateutil")
            install("colorama")
            install("rich")
            install("pyaes")
            install("rsa")
            install("pyasn1")
            install("certifi")
            install("idna")
            install("charset-normalizer")
        }
    }
}

dependencies {
    // Required by MainActivity.kt for the embedded JavaScript engine.
    implementation("org.mozilla:rhino:1.7.15")
}

android {
    namespace = "com.example.pocketpythonhost"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.pocketpythonhost"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        viewBinding = false
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
