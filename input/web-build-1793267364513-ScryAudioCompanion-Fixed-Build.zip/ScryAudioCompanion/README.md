# Scry Audio Companion (Android source project)

This is a separate companion app based on the Mic P Pro screenshots. It is **not merged into Telegram** and cannot inject effects into Telegram calls. Android does not let an ordinary third-party app alter another app's microphone/call audio stream.

## Features
- Mic permission and live input-level check
- Volume enhancer, bass/equalizer controls for this app's own music player (device support varies)
- Pick an audio file and play/pause/seek
- Dark navy + cyan interface

## Build APK using GitHub Actions (phone-friendly)
1. Create a GitHub repository and upload the contents of this folder (not the enclosing folder).
2. Open the repository's **Actions** tab.
3. Choose **Build Android APK** and tap **Run workflow** (or wait for the first push build).
4. Open the completed run and download the `ScryAudioCompanion-debug-apk` artifact. Extract it to get `app-debug.apk`.

## Build locally
Install Android Studio / JDK 17 / Android SDK 35, open this folder in Android Studio, then run the `assembleDebug` Gradle task.

The generated debug APK is unsigned for Play Store distribution but can normally be installed directly after allowing installs from that source. Audio effect support depends on Android device/vendor implementation.


## Build-failure fix
The Gradle build config explicitly targets Java 17 for both Java and Kotlin to resolve the reported `compileDebugJavaWithJavac (1.8)` vs `compileDebugKotlin (17)` mismatch. This source ZIP still needs a successful GitHub Actions build before the APK can be considered verified.
