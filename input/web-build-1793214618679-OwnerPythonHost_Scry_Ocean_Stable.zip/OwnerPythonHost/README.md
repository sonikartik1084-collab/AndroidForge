# 𝐒ᴄʀʏ 𓇼 Ocean Host — OwnerPythonHost

An Android-only, app-private Python script manager with a deep-ocean / sea-glass UI, soft emojis and rounded buttons. Owner branding: **𝐒ᴄʀʏ**.

## Features
- Import `.py` files from the Android document picker (1 MB per file limit).
- Run one script at a time, request cooperative stop, and reset the Python runtime stop flag.
- View recent output/errors, delete scripts, and view app-private storage usage.
- Ocean Terminal commands: `help`, `ls`, `pwd`, `cat NAME.py`, `run NAME.py`, `stop`, `restart`, `logs`, `storage`, `rm NAME.py`, `echo TEXT`, `clear`, `pip install PACKAGE`, `pip list`, and `pip uninstall PACKAGE`.
- Script files and logs stay in app-private storage. The app requests no Internet permission.

## Important terminal / pip note
The terminal is a built-in app command console, not a general Linux/Android shell. It intentionally does not execute arbitrary OS commands. `pip install PACKAGE` records a dependency request in app-private storage; it does **not** install packages into an already-built APK. Chaquopy dependencies generally need to be added to `app/build.gradle` under `python { pip { install "package-name" } }` and the APK rebuilt. Packages requiring unsupported native binaries or operating-system tools may not work.

## Runtime limitations
- This is a local Android app, not a 24/7 cloud host. Android may suspend the app when backgrounded.
- Stop is cooperative: a script blocked forever in a native call may not stop. Restart resets the stop flag; it does not forcibly kill a running Python thread.
- The app has no Internet permission; scripts cannot rely on network access unless the manifest is deliberately changed and the project rebuilt.
- Validation performed here: ZIP structure, AndroidManifest XML parsing, and embedded Python syntax parsing. A full Android/Gradle build and device test were not available in this environment, so a successful GitHub Actions build is still required before installation.

## Build from an Android phone using GitHub Actions
1. Download the project ZIP and upload it to the root of your GitHub repository as `OwnerPythonHost_Project.zip`, replacing the old ZIP.
2. Commit the change to `main`. The repository's `.github/workflows/build.yml` should run when that ZIP changes.
3. Open **Actions**, select the latest `Build Android APK` run, and inspect any failed step's logs if it fails.
4. On success, download the `OwnerPythonHost-debug-apk` artifact ZIP and extract it to obtain the installable debug APK.
5. Install only APKs built from your own repository. Android may ask you to allow installs from your browser/file manager.

The source project ZIP is not itself an APK. GitHub Actions must complete successfully to produce the APK.
