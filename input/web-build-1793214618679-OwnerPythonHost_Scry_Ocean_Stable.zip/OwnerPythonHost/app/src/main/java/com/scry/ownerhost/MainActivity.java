package com.scry.ownerhost;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private static final int PICK_PY = 101;
    // Ocean palette: deep navy, teal, sea-glass and soft silver.
    private static final int BG = Color.rgb(9, 22, 36);
    private static final int PANEL = Color.rgb(18, 39, 57);
    private static final int PANEL_2 = Color.rgb(23, 49, 68);
    private static final int TEAL = Color.rgb(82, 211, 205);
    private static final int MINT = Color.rgb(177, 244, 231);
    private static final int TEXT = Color.rgb(237, 247, 250);
    private static final int MUTED = Color.rgb(160, 188, 201);
    private static final int LINE = Color.rgb(43, 78, 96);

    private File rootDir, scriptsDir, logsDir;
    private LinearLayout main, fileList;
    private TextView status, logView, storageView;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean isRunning = false;
    private volatile String activeName = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        rootDir = new File(getFilesDir(), "owner_host");
        scriptsDir = new File(rootDir, "scripts");
        logsDir = new File(rootDir, "logs");
        scriptsDir.mkdirs(); logsDir.mkdirs();
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        buildUi();
        refreshFiles();
    }

    private GradientDrawable shape(int color, int strokeColor, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * getResources().getDisplayMetrics().density);
        if (strokeColor != 0) d.setStroke((int)(1 * getResources().getDisplayMetrics().density), strokeColor);
        return d;
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(18), dp(22), dp(18), dp(28)); main.setBackgroundColor(BG);
        scroll.addView(main);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackground(shape(PANEL, LINE, 24));
        TextView eyebrow = text("𓇼  PRIVATE WORKSPACE  ☁️", 11, TEAL, true);
        hero.addView(eyebrow);
        TextView title = text("𝐒ᴄʀʏ 𓇼 Ocean Host", 25, TEXT, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2); tp.topMargin = dp(8); hero.addView(title, tp);
        TextView subtitle = text("Private Python workspace • ୨୧", 14, MUTED, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(5); hero.addView(subtitle, sp);
        TextView privacy = text("🔒  Owner: 𝐒ᴄʀʏ  •  Local app storage", 12, MINT, false);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2); pp.topMargin = dp(14); hero.addView(privacy, pp);
        main.addView(hero, fullWidth());

        addSectionSpace(14);
        addButton("＋  Upload Python file  🎀", v -> openPicker(), TEAL, BG);
        addButton("↻  Refresh files & storage  ☁️", v -> refreshFiles(), PANEL_2, TEXT);
        addButton("■  Stop current script  ୨୧", v -> stopScript(), PANEL_2, TEXT);
        addButton("⟲  Restart Python runtime  ✧", v -> restartRuntime(), PANEL_2, TEXT);
        addButton("▤  Show latest logs  🪽", v -> showLogs(), PANEL_2, TEXT);
        addButton("⌘  Ocean Terminal  𓇼", v -> showTerminal(), PANEL_2, MINT);

        LinearLayout statusCard = card();
        status = text("✦  Status: idle", 14, MINT, true); statusCard.addView(status);
        storageView = text("☁️  Storage used: calculating…", 13, MUTED, false);
        LinearLayout.LayoutParams svp = new LinearLayout.LayoutParams(-1, -2); svp.topMargin = dp(9); statusCard.addView(storageView, svp);
        LinearLayout.LayoutParams scp = fullWidth(); scp.topMargin = dp(12); main.addView(statusCard, scp);

        addHeading("YOUR FILES  🐚");
        fileList = new LinearLayout(this); fileList.setOrientation(LinearLayout.VERTICAL); main.addView(fileList, fullWidth());
        addHeading("LATEST OUTPUT  ✧");
        logView = text("No logs yet. Run a Python file to see its output here.", 12, MINT, false);
        logView.setTextIsSelectable(true); logView.setPadding(dp(14), dp(14), dp(14), dp(14));
        logView.setBackground(shape(PANEL, LINE, 18));
        main.addView(logView, fullWidth());
        TextView footer = text("⋆｡°✩  made for your little ocean of code  ୨୧", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER); LinearLayout.LayoutParams fp = fullWidth(); fp.topMargin = dp(20); main.addView(footer, fp);
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams fullWidth() { return new LinearLayout.LayoutParams(-1, -2); }
    private void addSectionSpace(int h) { View v = new View(this); main.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15), dp(14), dp(15), dp(14)); c.setBackground(shape(PANEL, LINE, 20)); return c;
    }
    private void addHeading(String label) {
        TextView h = text(label, 13, TEAL, true); h.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams p = fullWidth(); p.topMargin = dp(22); p.bottomMargin = dp(9); main.addView(h, p);
    }
    private void addButton(String label, View.OnClickListener click, int background, int foreground) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(foreground); b.setGravity(Gravity.CENTER); b.setPadding(dp(12), dp(7), dp(12), dp(7));
        b.setBackground(shape(background, background == TEAL ? 0 : LINE, 18));
        b.setElevation(dp(1));
        LinearLayout.LayoutParams lp = fullWidth(); lp.setMargins(0, dp(4), 0, dp(4));
        main.addView(b, lp); b.setOnClickListener(click);
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_PY);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_PY || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData(); String name = displayName(uri);
        if (name == null || !name.toLowerCase().endsWith(".py") || !name.matches("[A-Za-z0-9_.-]{1,80}\\.py")) {
            toast("Choose a .py file with a simple filename. 🎀"); return;
        }
        File dest = new File(scriptsDir, name);
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(dest)) {
            if (in == null) throw new IOException("Could not open file");
            byte[] buf = new byte[8192]; int n; long total = 0;
            while ((n = in.read(buf)) > 0) { total += n; if (total > 1024 * 1024) throw new IOException("File exceeds 1 MB limit"); out.write(buf, 0, n); }
            toast("Uploaded " + name + " ୨୧"); refreshFiles();
        } catch (Exception e) { dest.delete(); toast("Upload failed: " + e.getMessage()); }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0) return c.getString(ix); }
        } catch (Exception ignored) {}
        return null;
    }

    private void refreshFiles() {
        fileList.removeAllViews();
        File[] fs = scriptsDir.listFiles((d,n) -> n.toLowerCase().endsWith(".py"));
        if (fs == null || fs.length == 0) {
            TextView empty = text("☁️  No Python files yet. Upload one above.", 13, MUTED, false);
            LinearLayout c = card(); c.addView(empty); fileList.addView(c, fullWidth());
        } else {
            for (File f : fs) {
                LinearLayout row = card();
                TextView nm = text("🐍  " + f.getName(), 15, TEXT, true); row.addView(nm);
                TextView size = text(human(f.length()) + "  ·  Python script", 12, MUTED, false);
                LinearLayout.LayoutParams zp = fullWidth(); zp.topMargin = dp(5); row.addView(size, zp);
                LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
                Button run = miniButton("♡ Run", TEAL, BG); Button del = miniButton("⌫ Delete", PANEL_2, TEXT);
                actions.addView(run, new LinearLayout.LayoutParams(0, dp(46), 1));
                View gap = new View(this); actions.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
                actions.addView(del, new LinearLayout.LayoutParams(0, dp(46), 1));
                LinearLayout.LayoutParams ap = fullWidth(); ap.topMargin = dp(10); row.addView(actions, ap);
                LinearLayout.LayoutParams rp = fullWidth(); rp.setMargins(0, 0, 0, dp(9)); fileList.addView(row, rp);
                run.setOnClickListener(v -> runScript(f)); del.setOnClickListener(v -> confirmDelete(f));
            }
        }
        long used = folderSize(rootDir);
        storageView.setText("☁️  Storage used: " + human(used) + "   ·   Files: " + (fs == null ? 0 : fs.length));
    }

    private Button miniButton(String label, int background, int foreground) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(13); b.setTextColor(foreground);
        b.setPadding(dp(6), 0, dp(6), 0); b.setBackground(shape(background, LINE, 15)); return b;
    }

    private void runScript(File f) {
        if (isRunning) { toast("A script is already running. Stop it first. ୨୧"); return; }
        isRunning = true; activeName = f.getName(); status.setText("✦  Status: running " + activeName);
        File log = new File(logsDir, f.getName() + ".log");
        try { new FileOutputStream(log, false).close(); } catch(Exception ignored) {}
        executor.submit(() -> {
            try { Python.getInstance().getModule("host_runtime").callAttr("run_script", f.getAbsolutePath(), log.getAbsolutePath()); }
            catch (Throwable e) { appendLog(log, "APP ERROR: " + e.toString() + "\n"); }
            finally { runOnUiThread(() -> { isRunning = false; activeName = ""; status.setText("✦  Status: idle"); showLogFile(log); refreshFiles(); }); }
        });
    }

    private void stopScript() {
        if (!isRunning) { toast("No script is running. ☁️"); return; }
        try { Python.getInstance().getModule("host_runtime").callAttr("request_stop"); status.setText("✦  Stop requested for " + activeName); toast("Stop requested. A script that blocks forever may not stop."); }
        catch (Throwable e) { toast("Stop request failed: " + e.getMessage()); }
    }

    private void restartRuntime() {
        if (isRunning) { toast("Stop the script first. Python threads cannot safely be force-killed."); return; }
        try { Python.getInstance().getModule("host_runtime").callAttr("reset_stop"); status.setText("✦  Status: Python runtime ready"); toast("Python runtime ready 𓇼"); }
        catch (Throwable e) { toast("Runtime reset failed: " + e.getMessage()); }
    }

    private void confirmDelete(File f) {
        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
            .setTitle("Delete " + f.getName() + "? ୨୧").setMessage("This cannot be undone.")
            .setNegativeButton("Keep file", null).setPositiveButton("⌫ Delete", (d,w) -> {
                if (f.getName().equals(activeName)) { toast("Stop this script first."); return; }
                boolean ok = f.delete(); toast(ok ? "Deleted ୨୧" : "Delete failed"); refreshFiles();
            }).create();
        dialog.setOnShowListener(v -> { dialog.getButton(-1).setTextColor(TEAL); dialog.getButton(-2).setTextColor(MUTED); });
        dialog.show();
    }

    private void showTerminal() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(4));
        box.setBackgroundColor(BG);

        TextView hint = text("𓇼  OWNER CONSOLE  ·  𝐒ᴄʀʏ", 12, TEAL, true);
        box.addView(hint, fullWidth());
        TextView note = text("App-local commands only — not a full Android/Linux shell.", 11, MUTED, false);
        LinearLayout.LayoutParams np = fullWidth(); np.topMargin = dp(5); box.addView(note, np);

        ScrollView terminalScroll = new ScrollView(this);
        terminalScroll.setFillViewport(false);
        TextView output = text("$ help\nType help to see commands.\n", 12, MINT, false);
        output.setTypeface(Typeface.MONOSPACE);
        output.setTextIsSelectable(true);
        output.setPadding(dp(12), dp(12), dp(12), dp(12));
        output.setBackground(shape(PANEL, LINE, 16));
        terminalScroll.addView(output);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(240));
        op.topMargin = dp(10); box.addView(terminalScroll, op);

        EditText command = new EditText(this);
        command.setSingleLine(true);
        command.setTextColor(TEXT);
        command.setHintTextColor(MUTED);
        command.setHint("help  ·  ls  ·  pip install requests");
        command.setTextSize(13);
        command.setPadding(dp(12), dp(8), dp(12), dp(8));
        command.setBackground(shape(PANEL_2, LINE, 14));
        LinearLayout.LayoutParams cp = fullWidth(); cp.topMargin = dp(10); box.addView(command, cp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button execute = miniButton("Run command  ↵", TEAL, BG);
        Button clear = miniButton("Clear ✧", PANEL_2, TEXT);
        actions.addView(execute, new LinearLayout.LayoutParams(0, dp(46), 1));
        View gap = new View(this); actions.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        actions.addView(clear, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams ap = fullWidth(); ap.topMargin = dp(8); box.addView(actions, ap);

        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
            .setTitle("⌘  Ocean Terminal  ୨୧")
            .setView(box)
            .setNegativeButton("Close", null)
            .create();
        execute.setOnClickListener(v -> {
            String cmd = command.getText().toString().trim();
            if (cmd.isEmpty()) return;
            output.append("\n$ " + cmd + "\n");
            executeTerminalCommand(cmd, output, dialog);
            command.setText("");
            terminalScroll.post(() -> terminalScroll.fullScroll(View.FOCUS_DOWN));
        });
        clear.setOnClickListener(v -> output.setText("$ clear\nTerminal cleared. 𓇼\n"));
        dialog.setOnShowListener(v -> {
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(TEAL);
        });
        dialog.show();
        dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(TEAL);
    }

    private void executeTerminalCommand(String raw, TextView output, android.app.AlertDialog dialog) {
        String cmd = raw.trim();
        String lower = cmd.toLowerCase(java.util.Locale.ROOT);
        try {
            if (lower.equals("help")) {
                output.append("Commands:\n  help                 show this help\n  ls                   list Python scripts\n  pwd                  show app-private script path\n  cat NAME.py          show a script\n  run NAME.py          run a script\n  stop                 request script stop\n  restart              reset runtime stop flag\n  logs                 show latest log\n  storage              show private storage usage\n  rm NAME.py           delete a script\n  pip install PACKAGE  stage package for next APK build\n  pip list             show staged package requests\n  pip uninstall NAME   remove a staged package request\n  clear                clear console\n\nThis is an app command console, not a Linux shell.\n");
            } else if (lower.equals("clear")) {
                output.setText("$ clear\nTerminal cleared. 𓇼\n");
            } else if (lower.equals("ls")) {
                File[] files = scriptsDir.listFiles((d,n) -> n.toLowerCase().endsWith(".py"));
                if (files == null || files.length == 0) output.append("(no .py files)\n");
                else for (File f : files) output.append(f.getName() + "  ·  " + human(f.length()) + "\n");
            } else if (lower.equals("pwd")) {
                output.append(scriptsDir.getAbsolutePath() + "\n");
            } else if (lower.equals("storage")) {
                output.append("App-private workspace: " + human(folderSize(rootDir)) + "\n");
            } else if (lower.equals("stop")) {
                stopScript(); output.append(isRunning ? "Stop requested. Some blocked scripts may not stop.\n" : "No script is running.\n");
            } else if (lower.equals("restart")) {
                restartRuntime(); output.append(isRunning ? "Stop the active script before restart.\n" : "Runtime stop flag reset.\n");
            } else if (lower.equals("logs")) {
                showLogs(); output.append(logView.getText() + "\n");
            } else if (lower.startsWith("run ") || lower.startsWith("python ")) {
                String name = cmd.substring(cmd.indexOf(' ') + 1).trim();
                File f = safeScript(name);
                if (f == null || !f.isFile()) output.append("File not found. Use ls to list scripts.\n");
                else { runScript(f); output.append("Run requested: " + f.getName() + "\n"); }
            } else if (lower.startsWith("cat ")) {
                File f = safeScript(cmd.substring(4).trim());
                if (f == null || !f.isFile()) output.append("File not found.\n");
                else output.append(readSmallFile(f, 16000) + "\n");
            } else if (lower.startsWith("rm ")) {
                File f = safeScript(cmd.substring(3).trim());
                if (f == null || !f.isFile()) output.append("File not found; only .py files in your app workspace can be deleted.\n");
                else if (f.getName().equals(activeName)) output.append("Stop the active script before deleting it.\n");
                else { boolean ok = f.delete(); output.append(ok ? "Deleted " + f.getName() + "\n" : "Delete failed.\n"); refreshFiles(); }
            } else if (lower.equals("pip list")) {
                File req = new File(rootDir, "pip_requests.txt");
                String pending = readSmallFile(req, 8000).trim();
                output.append(pending.isEmpty() ? "No staged package requests.\n" : "Packages staged for a future APK build (not installed in this running APK):\n" + pending + "\n");
            } else if (lower.startsWith("pip install ")) {
                String pkg = cmd.substring("pip install ".length()).trim();
                if (!pkg.matches("[A-Za-z0-9_.-]{1,80}(==[A-Za-z0-9_.+-]{1,40})?")) {
                    output.append("Use: pip install package-name  (optional version: package==1.2.3)\n");
                } else {
                    File req = new File(rootDir, "pip_requests.txt");
                    java.util.LinkedHashSet<String> packages = readLines(req);
                    packages.add(pkg);
                    writeLines(req, packages);
                    output.append("Staged: " + pkg + "\nImportant: Chaquopy packages are bundled at APK build time. This command records your request; it cannot install into the already-built APK. Add the package to app/build.gradle under python { pip { install \"" + pkg + "\" } }, then rebuild the APK. Native/OS packages may not be supported.\n");
                }
            } else if (lower.startsWith("pip uninstall ")) {
                String pkg = cmd.substring("pip uninstall ".length()).trim();
                File req = new File(rootDir, "pip_requests.txt");
                java.util.LinkedHashSet<String> packages = readLines(req);
                boolean removed = packages.removeIf(x -> x.equalsIgnoreCase(pkg));
                writeLines(req, packages);
                output.append(removed ? "Removed staged request: " + pkg + "\n" : "No matching staged request.\n");
            } else if (lower.startsWith("echo ")) {
                output.append(cmd.substring(5) + "\n");
            } else {
                output.append("Unknown command. Type help. No system shell commands are executed.\n");
            }
        } catch (Throwable e) {
            output.append("ERROR: " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()) + "\n");
        }
    }

    private File safeScript(String name) {
        if (name == null || !name.matches("[A-Za-z0-9_.-]{1,80}\\.py")) return null;
        try {
            File f = new File(scriptsDir, name).getCanonicalFile();
            return f.getParentFile().equals(scriptsDir.getCanonicalFile()) ? f : null;
        } catch (IOException e) { return null; }
    }

    private String readSmallFile(File f, int maxBytes) {
        if (f == null || !f.exists() || !f.isFile()) return "";
        try (FileInputStream in = new FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[2048]; int n;
            while ((n = in.read(buf)) > 0 && out.size() < maxBytes) out.write(buf, 0, Math.min(n, maxBytes - out.size()));
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) { return "Could not read file: " + e.getMessage(); }
    }

    private java.util.LinkedHashSet<String> readLines(File f) {
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
        String data = readSmallFile(f, 12000);
        for (String line : data.split("\\r?\\n")) if (!line.trim().isEmpty()) out.add(line.trim());
        return out;
    }

    private void writeLines(File f, java.util.Set<String> lines) throws IOException {
        try (FileOutputStream out = new FileOutputStream(f, false)) {
            for (String line : lines) out.write((line + "\n").getBytes(StandardCharsets.UTF_8));
        }
    }

    private void showLogs() {
        File[] fs = logsDir.listFiles();
        if (fs == null || fs.length == 0) { logView.setText("No logs yet. Run a Python file to see output. ✧"); return; }
        File latest = fs[0]; for (File f : fs) if (f.lastModified() > latest.lastModified()) latest = f; showLogFile(latest);
    }
    private void showLogFile(File f) {
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long start = Math.max(0, raf.length() - 12000); raf.seek(start); byte[] b = new byte[(int)(raf.length() - start)]; raf.readFully(b); logView.setText(new String(b, StandardCharsets.UTF_8));
        } catch (Exception e) { logView.setText("No output yet. " + e.getMessage()); }
    }
    private void appendLog(File f, String s) { try (FileOutputStream out = new FileOutputStream(f, true)) { out.write(s.getBytes(StandardCharsets.UTF_8)); } catch (Exception ignored) {} }
    private long folderSize(File f) { if (f == null || !f.exists()) return 0; if (f.isFile()) return f.length(); long n = 0; File[] children = f.listFiles(); if (children != null) for (File c : children) n += folderSize(c); return n; }
    private String human(long n) { if (n < 1024) return n + " B"; if (n < 1024*1024) return String.format("%.1f KB", n/1024.0); return String.format("%.1f MB", n/(1024.0*1024)); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdown(); }
}
