# Embedded Python runtime. Arbitrary Python threads cannot be safely force-killed.
import runpy
import sys
import threading
import traceback

_stop_event = threading.Event()

def request_stop():
    _stop_event.set()
    return True

def reset_stop():
    _stop_event.clear()
    return True

def host_should_stop():
    # Scripts with long loops can import this and check it periodically.
    return _stop_event.is_set()

def run_script(script_path, log_path):
    class Tee:
        def __init__(self, file_obj):
            self.file_obj = file_obj
        def write(self, text):
            self.file_obj.write(text)
            self.file_obj.flush()
            return len(text)
        def flush(self):
            self.file_obj.flush()
        def isatty(self):
            return False

    _stop_event.clear()
    try:
        with open(log_path, "w", encoding="utf-8", errors="replace") as log:
            old_out, old_err, old_path = sys.stdout, sys.stderr, list(sys.path)
            sys.stdout = Tee(log)
            sys.stderr = Tee(log)
            sys.path.insert(0, script_path.rsplit("/", 1)[0])
            try:
                print("Starting:", script_path)
                runpy.run_path(script_path, run_name="__main__")
                print("\nScript finished.")
            except SystemExit as e:
                print("Script exited:", e)
            except BaseException:
                traceback.print_exc()
            finally:
                sys.stdout, sys.stderr = old_out, old_err
                sys.path[:] = old_path
    except Exception:
        traceback.print_exc()
